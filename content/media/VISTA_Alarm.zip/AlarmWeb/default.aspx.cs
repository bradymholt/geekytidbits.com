﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Configuration;
using System.Web.Services;
using PogoPlugLibrary;

public partial class Alarm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
}
