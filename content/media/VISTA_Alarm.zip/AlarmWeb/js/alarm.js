﻿$(function() {
    $('.button').click(function() {
        AlarmHelper.ExecuteCommand(this);
    });

    $('.button').mousedown(function() {
        $(this).addClass('pressed');
    });

    $('.button').mouseup(function() {
        $(this).removeClass('pressed');
    });

    AlarmHelper.ListenForUpdates();
});

var AlarmHelper = {
    ExecuteCommand: function(target) {
        $.ajax({
            type: "POST",
            url: "command.asmx/Execute",
            data: "{command: '" + $(target).attr('id') + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json"
        });
    },
    UpdateStatus: function(newStatus) {
        $('#display').html(newStatus);
    }
};