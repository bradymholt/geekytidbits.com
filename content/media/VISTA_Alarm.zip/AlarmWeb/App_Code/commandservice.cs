﻿using System;
using System.Collections;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Text;
using System.Net;
using System.IO;
using System.Configuration;
using System.Web.Script.Services;
using System.IO.Pipes;

namespace Services
{
    [ScriptService]
    [WebService(Namespace = "http://myhome.getmyip.com/")]
    public class CommandService : System.Web.Services.WebService
    {

        private const string COMMAND_POUND = "Pound";

        public CommandService()
        {
        }

        [WebMethod]
        public void Execute(string command)
        {
            if (command.Length > COMMAND_POUND.Length && command.StartsWith(COMMAND_POUND))
            {
                //prefix for device command
                command = string.Concat(ConfigurationManager.AppSettings["command.special.prefix"], command);
            }

            string pipeName = ConfigurationManager.AppSettings["command.server.pipe.name"];
            NamedPipeClientStream client = new NamedPipeClientStream(".", pipeName, PipeDirection.Out);
            client.Connect(5000);

            using (StreamWriter sr = new StreamWriter(client))
            {
                sr.AutoFlush = true;
                sr.WriteLine(command);
            }
        }
    }
}