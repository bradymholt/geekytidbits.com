﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Pipes;
using System.IO;
using System.Net;
using System.Threading;
using System.Diagnostics;

namespace AlarmServer
{
    class CommandServer
    {
        private const string COMMAND_FORMAT = "cmd?cmd=";

        private string m_namedPipeName;
        private string m_commandTarget;
        public event EventHandler ClientConnected;
        public event EventHandler ClientDisconnected;
        NamedPipeServerStream m_server;
        public ServerStatusEnum State { get; set; }

        public CommandServer(string namedPipeName, string commandTargetBaseUrl)
        {
            m_commandTarget = string.Concat(commandTargetBaseUrl, COMMAND_FORMAT);
            m_namedPipeName = namedPipeName;
            m_server = new NamedPipeServerStream(m_namedPipeName, PipeDirection.In, 2, PipeTransmissionMode.Byte, PipeOptions.None);
            this.State = ServerStatusEnum.NotWaiting;
        }

        public void Start()
        {
            AsyncCallback connectCallback = new AsyncCallback(AsyncPipeCallback);
            m_server.BeginWaitForConnection(connectCallback, null);
            this.State = ServerStatusEnum.Waiting;
        }

        public void Stop()
        {
            try { m_server.Close(); }
            finally
            {
                this.State = ServerStatusEnum.Disconnected;

                if (this.ClientDisconnected != null)
                {
                    this.ClientDisconnected(this, null);
                }
            }
        }

        private void AsyncPipeCallback(IAsyncResult result)
        {
            m_server.EndWaitForConnection(result);

            this.State = ServerStatusEnum.Connected;

            if (this.ClientConnected != null)
            {
                this.ClientConnected(this, null);
            }

            using (StreamReader sr = new StreamReader(m_server))
            {
                while (true)
                {
                    string commands = sr.ReadLine();
                    Console.WriteLine(string.Concat("Commands received: ", commands));
                    ExecuteCommands(commands);
                    Console.WriteLine("done.");
                }
            }
        }

        public void ExecuteCommands(string commands)
        {
            string[] commandParts = commands.Split('-');
            foreach (string command in commandParts)
            {
                string commandUrl = string.Concat(m_commandTarget, command);
                Console.Write(string.Format("Sending command: {0}...", commandUrl));
                //send command

                var p = new System.Diagnostics.Process
                {
                    StartInfo = new ProcessStartInfo("wget", string.Concat("--spider ", commandUrl))
                    {
                        WorkingDirectory = "/tmp/",
                        RedirectStandardOutput = false,
                        RedirectStandardError = false,
                        UseShellExecute = true,
                        CreateNoWindow = true,
                    }
                };

                p.Start();
                p.WaitForExit();
            }
        }
    }
}
