﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceProcess;
using System.Net.Mail;
using Blinnikka.VistaIcm;
using System.Configuration;
using System.Threading;
using Prowl;

namespace AlarmServer
{
    public class AlarmServerService : ServiceBase
    {
        SecurityModule m_securityModule;
        CommandServer m_commandServer;
        string m_commandPipeName;
        string m_commandTarget;
        string m_normalEmailNotificationsTo;
        string m_emergencyEmailNotificationsTo;
        string m_alarmWebUrl;
        bool m_sendArmNotifications;
        bool m_sendDisarmNotifications;
        bool m_sendNotificationsWhenGarageDoorFaultsWhenArmAway;
        int m_sendNotificationsWhenGarageDoorFaultsWhenArmAwayDelaySeconds;
        bool m_armStayWhenGarageDoorFaults;
        TimeSpan m_armStayWhenGarageDoorFaultsStartTimeOfDay;
        TimeSpan m_armStayWhenGarageDoorFaultsEndTimeOfDay;
        int m_armStayWhenGarageDoorFaultsZoneNumber;
        bool m_armStayWhenGarageDoorFaultsSkipWeekends;
        int m_armStayWhenGarageDoorFaultsDelaySeconds;
        string m_armStayCommand;

        public AlarmServerService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (Initialize())
            {
                Console.WriteLine("Listening for alarms...");
                m_securityModule.AlarmStateChanged += new EventHandler<EventArgs>(s_securityModule_AlarmStateChanged);
                Console.WriteLine("Listening for arm changes...");
                m_securityModule.ArmStatusChanged += new EventHandler<EventArgs>(m_securityModule_ArmStatusChanged_Notify);
                Console.WriteLine("Wiring up (Garage Door Open after Arm AWAY) notifications...");
                m_securityModule.ArmStatusChanged += new EventHandler<EventArgs>(m_securityModule_ArmStatusChanged_CheckGarageDoorNotify);
                Console.WriteLine("Wiring up (Arm STAY after Garage Door Closed) hook...");
                m_securityModule.ZoneChanged += new EventHandler<ZoneChangedEventArgs>(m_securityModule_ZoneChanged_ArmStayWhenGarageDoorFaults);
                m_securityModule.ZoneChanged += new EventHandler<ZoneChangedEventArgs>(m_securityModule_ZoneChanged);
                Console.WriteLine("Wiring up Power Failure notifications...");
                m_securityModule.PowerFailure += new EventHandler<EventArgs>(m_securityModule_PowerFailure);
                m_securityModule.PowerRestored += new EventHandler<EventArgs>(m_securityModule_PowerRestored);

                Console.WriteLine("Starting command server...");
                m_commandServer = new CommandServer(m_commandPipeName, m_commandTarget);
                m_commandServer.ClientConnected += new EventHandler(commandServer_ClientConnected);
                m_commandServer.ClientDisconnected += new EventHandler(commandServer_ClientDisconnected);
                m_commandServer.Start();
            }
        }

        protected override void OnStop()
        {
            m_securityModule.AlarmStateChanged -= new EventHandler<EventArgs>(s_securityModule_AlarmStateChanged);
            m_securityModule.ArmStatusChanged -= new EventHandler<EventArgs>(m_securityModule_ArmStatusChanged_Notify);
            m_securityModule.ArmStatusChanged -= new EventHandler<EventArgs>(m_securityModule_ArmStatusChanged_CheckGarageDoorNotify);
            m_securityModule.ZoneChanged -= new EventHandler<ZoneChangedEventArgs>(m_securityModule_ZoneChanged_ArmStayWhenGarageDoorFaults);
            m_securityModule.PowerFailure -= new EventHandler<EventArgs>(m_securityModule_PowerFailure);
            m_securityModule.PowerRestored -= new EventHandler<EventArgs>(m_securityModule_PowerRestored);

            m_commandServer.Stop();
        }

        #region Service Methods
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.ServiceName = "AlarmService";
        }
        #endregion

        bool Initialize()
        {
            bool success = false;

            try
            {
                Console.Write("Initializing...");
                m_commandPipeName = ConfigurationManager.AppSettings["command.server.pipe.name"];
                m_commandTarget = ConfigurationManager.AppSettings["command.target"];
                m_normalEmailNotificationsTo = ConfigurationManager.AppSettings["normalEmailNotificationsTo"];
                m_emergencyEmailNotificationsTo = ConfigurationManager.AppSettings["emergencyEmailNotificationsTo"];
                m_alarmWebUrl = ConfigurationManager.AppSettings["alarmWebUrl"];
                m_sendArmNotifications = Convert.ToBoolean(ConfigurationManager.AppSettings["sendArmNotifications"]);
                m_sendDisarmNotifications = Convert.ToBoolean(ConfigurationManager.AppSettings["sendDisarmNotifications"]);
                m_sendNotificationsWhenGarageDoorFaultsWhenArmAway = Convert.ToBoolean(ConfigurationManager.AppSettings["sendNotificationsWhenGarageDoorFaultsWhenArmAway"]);
                m_sendNotificationsWhenGarageDoorFaultsWhenArmAwayDelaySeconds = Convert.ToInt32(ConfigurationManager.AppSettings["sendNotificationsWhenGarageDoorFaultsWhenArmAwayDelaySeconds"]);
                m_armStayWhenGarageDoorFaults = Convert.ToBoolean(ConfigurationManager.AppSettings["armStayWhenGarageDoorFaults"]);
                m_armStayWhenGarageDoorFaultsStartTimeOfDay = TimeSpan.Parse(ConfigurationManager.AppSettings["armStayWhenGarageDoorFaultsStartTimeOfDay"]);
                m_armStayWhenGarageDoorFaultsEndTimeOfDay = TimeSpan.Parse(ConfigurationManager.AppSettings["armStayWhenGarageDoorFaultsEndTimeOfDay"]);
                m_armStayWhenGarageDoorFaultsZoneNumber = Convert.ToInt32(ConfigurationManager.AppSettings["armStayWhenGarageDoorFaultsZoneNumber"]);
                m_armStayCommand = ConfigurationManager.AppSettings["armStayCommand"];
                m_armStayWhenGarageDoorFaultsDelaySeconds = Convert.ToInt32(ConfigurationManager.AppSettings["armStayWhenGarageDoorFaultsDelaySeconds"]);
                m_armStayWhenGarageDoorFaultsSkipWeekends = Convert.ToBoolean(ConfigurationManager.AppSettings["armStayWhenGarageDoorFaultsSkipWeekends"]);

                m_securityModule = new SecurityModule();
                m_securityModule.Start();

                Console.WriteLine("done!");
                success = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Concat("Initialization failed: {0}", ex.Message));
                success = false;
            }

            return success;
        }

        void commandServer_ClientConnected(object sender, EventArgs e)
        {
            Console.WriteLine("Command client connected...");
        }

        void commandServer_ClientDisconnected(object sender, EventArgs e)
        {
            Console.WriteLine("Command client disconnected...");
        }

        void displayServer_ClientConnected(object sender, EventArgs e)
        {
            Console.WriteLine("Display client connected...");
        }

        void displayServer_ClientDisconnected(object sender, EventArgs e)
        {
            Console.WriteLine("Display client disconnected...");
        }

        private void Notify(string subject, string detail, bool isEmergency)
        {
            if (isEmergency || m_sendNotificationsWhenGarageDoorFaultsWhenArmAway)
            {
                Console.WriteLine(string.Format("Notify: {0} / {1}", subject, detail));

                //email
                string toEmail = isEmergency ? m_emergencyEmailNotificationsTo : m_normalEmailNotificationsTo;
                if (!string.IsNullOrEmpty(toEmail))
                {
                    MailMessage mail = new MailMessage();
                    mail.To.Add(toEmail);
                    mail.Subject = subject;
                    mail.Body = detail;

                    SmtpClient mailClient = new SmtpClient();
                    try
                    {
                        mailClient.Send(mail);
                    }
                    catch (Exception mex)
                    {
                        Console.WriteLine(mex);
                    }
                }


                //growl
                ProwlNotification notification =
                   new ProwlNotification
                   {
                       Description = detail,
                       Event = subject,
                       Url = m_alarmWebUrl,
                       Priority = isEmergency ? ProwlNotificationPriority.Emergency : ProwlNotificationPriority.Normal
                   };

                ProwlClient prowl = new ProwlClient();
                try
                {
                    prowl.PostNotification(notification);
                }
                catch (Exception pex)
                {
                    Console.WriteLine(pex.Message);
                }
            }
        }

        #region Actions
        void s_securityModule_AlarmStateChanged(object sender, EventArgs e)
        {
            Console.WriteLine(string.Concat("Alarm status changed: ", m_securityModule.AlarmState.ToString()));

            if (m_securityModule.AlarmState == AlarmState.Alarm || m_securityModule.AlarmState == AlarmState.Fire)
            {
                string subject = string.Concat("House: ", m_securityModule.AlarmState.ToString().ToUpper(), "!");
                Zone faultedZone = m_securityModule.Zones.Values.FirstOrDefault(z => z.IsFaulted);
                string faltedZoneDescription = m_securityModule.Display;
                if (faultedZone != null && !string.IsNullOrEmpty(faultedZone.Name))
                {
                    faltedZoneDescription = faultedZone.Name;
                }

                Notify(subject, faltedZoneDescription, true);
            }
        }

        void m_securityModule_ArmStatusChanged_Notify(object sender, EventArgs e)
        {
            Console.WriteLine(string.Concat("Arm status changed: ", m_securityModule.ArmStatus.ToString()));

            string armStatus = string.Empty;
            bool notify = false;
            switch (m_securityModule.ArmStatus)
            {
                case ArmStatus.ArmedStay:
                    armStatus = "Arm/Stay";
                    notify = m_sendArmNotifications;
                    break;
                case ArmStatus.ArmedAway:
                    armStatus = "Arm/Away";
                    notify = m_sendArmNotifications;
                    break;
                case ArmStatus.Disarmed:
                    armStatus = "Disarmed";
                    notify = m_sendDisarmNotifications;
                    break;
                default:
                    armStatus = m_securityModule.ArmStatus.ToString();
                    break;
            }

            if (notify)
            {
                string subject = string.Format("House: {0}", armStatus);
                string detail = DateTime.Now.ToShortTimeString();
                Notify(subject, detail, false);
            }
        }

        protected void m_securityModule_ZoneChanged(object sender, ZoneChangedEventArgs e)
        {
            Console.WriteLine(string.Format("Zone: {0} ({1}) {2}", e.Zone.Id.ToString(), e.Zone.Name, e.Zone.IsFaulted ? "FAULTED" : "READY"));
        }

        void m_securityModule_PowerRestored(object sender, EventArgs e)
        {
            Console.WriteLine("Power Restored");
            Notify("Power Restored", DateTime.Now.ToShortTimeString(), false);
        }

        void m_securityModule_PowerFailure(object sender, EventArgs e)
        {
            Console.WriteLine("Power Failure");
            Notify("Power Failure", DateTime.Now.ToShortTimeString(), false);
        }

        void m_securityModule_ArmStatusChanged_CheckGarageDoorNotify(object sender, EventArgs e)
        {
            if (m_sendNotificationsWhenGarageDoorFaultsWhenArmAway
                && m_securityModule.ArmStatus == ArmStatus.ArmedAway)
            {
                Console.WriteLine(string.Format("Arm AWAY.  Waiting {0} seconds and will check for Check Condition (Garage Door open)...", m_sendNotificationsWhenGarageDoorFaultsWhenArmAwayDelaySeconds));
                //wait and listen for CHECK condition (i.e. Garage Door is open)       
                Thread.Sleep(TimeSpan.FromSeconds(m_sendNotificationsWhenGarageDoorFaultsWhenArmAwayDelaySeconds));

                string displayText = string.Empty;
                for (int i = 0; i <= 3; i++) //take 3 samples of display
                {
                    if (!displayText.Contains(m_securityModule.Display))
                    {
                        displayText += string.Concat(m_securityModule.Display, " ");
                    }

                    Thread.Sleep(TimeSpan.FromSeconds(1)); //wait 1 second before taking next sample
                }

                if (displayText.ToUpper().Contains("CHECK"))
                {
                    Console.WriteLine(string.Format("Garage Door is open! ({0}).  Sending notification...", displayText));
                    Notify("Armed/Away Check", displayText, false);
                }
                else
                {
                    Console.WriteLine(string.Format("Garage Door is closed.  No notification needed.", displayText));
                }
            }
        }

        void m_securityModule_ZoneChanged_ArmStayWhenGarageDoorFaults(object sender, ZoneChangedEventArgs e)
        {
            if (m_armStayWhenGarageDoorFaults
                && e.Zone.Id == m_armStayWhenGarageDoorFaultsZoneNumber
                && e.Zone.IsFaulted == true
                && m_securityModule.ArmStatus == ArmStatus.Disarmed
                && DateTime.Now.TimeOfDay >= m_armStayWhenGarageDoorFaultsStartTimeOfDay
                && DateTime.Now.TimeOfDay <= m_armStayWhenGarageDoorFaultsEndTimeOfDay
                && (!m_armStayWhenGarageDoorFaultsSkipWeekends || (DateTime.Now.DayOfWeek != DayOfWeek.Saturday && DateTime.Now.DayOfWeek != DayOfWeek.Sunday)))
            {
                Console.WriteLine(string.Format("Garage Door FAULT (Zone {0}).  Waiting {1} seconds and will Arm STAY if Garage Door closed...", m_armStayWhenGarageDoorFaultsZoneNumber, m_armStayWhenGarageDoorFaultsDelaySeconds));

                //wait form garage door to close
                Thread.Sleep(TimeSpan.FromSeconds(m_armStayWhenGarageDoorFaultsDelaySeconds));

                //arm if garage door is now closed
                if (!e.Zone.IsFaulted && m_securityModule.ArmStatus == ArmStatus.Disarmed)
                {
                    Console.WriteLine(string.Format("Garage Door NO FAULT (Zone {0}).  Armming STAY...", m_armStayWhenGarageDoorFaultsZoneNumber));
                    m_commandServer.ExecuteCommands(m_armStayCommand);
                }
                else
                {
                    Console.WriteLine(string.Format("Garage Door FAULT (Zone {0}).  Skip Arm because Garage is still open.", m_armStayWhenGarageDoorFaultsZoneNumber));
                }
            }
        }


        #endregion
    }
}
