﻿using System;
using System.Linq;
using System.IO;
using System.IO.Pipes;
using System.Threading;
using Blinnikka.VistaIcm;
using System.Collections.Generic;
using System.Net.Mail;
using System.Configuration;
using System.Text;
using System.ServiceProcess;

namespace AlarmServer
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
			{ 
				new AlarmServerService() 
			};
            ServiceBase.Run(ServicesToRun);
        }
    }
}
