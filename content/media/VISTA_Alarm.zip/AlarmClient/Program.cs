﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Pipes;
using System.Configuration;

namespace AlarmClient
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0 || string.IsNullOrEmpty(args[0]))
            {
                Console.WriteLine("usage: alarmclient.exe [commands delimited with dash '-'] (ex. alarmclient.exe 4-3-6-2)");
            }
            else
            {
                Console.Write("Connecting to server...");

                string pipName = ConfigurationManager.AppSettings["command.server.pipe.name"];
                NamedPipeClientStream client = new NamedPipeClientStream(".", pipName, PipeDirection.Out);
                client.Connect(5000);

                Console.WriteLine("connected!");
                Console.Write("Executing commands...");

                using (StreamWriter sr = new StreamWriter(client))
                {
                    sr.AutoFlush = true;
                    sr.WriteLine(args[0]);
                }

                client.WaitForPipeDrain();

                Console.WriteLine("done!");
            }
        }
    }
}
